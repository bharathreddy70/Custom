/**
 *
 */
package my.bookstore.core.services.impl;

import de.hybris.platform.core.model.user.CustomerModel;

import java.util.List;

import my.bookstore.core.daos.RentalDao;
import my.bookstore.core.model.BookModel;
import my.bookstore.core.model.RentalModel;
import my.bookstore.core.services.RentalService;


/**
 * @author training1
 *
 */
public class DefaultRentalService implements RentalService
{
    RentalDao rentalDao;

    /**
     * @param rentalDao
     */
    public DefaultRentalService(final RentalDao rentalDao)
    {
        super();
        this.rentalDao = rentalDao;
    }

    @Override
    public List<RentalModel> getActiveRentalsForCustomer(final CustomerModel customer)
    {
        return rentalDao.getActiveRentalsForCustomer(customer);
    }

    @Override
    public List<BookModel> getMostRentedBooks(int numberOfBooks) {
        return rentalDao.getMostRentedBooks(numberOfBooks);
    }



}
