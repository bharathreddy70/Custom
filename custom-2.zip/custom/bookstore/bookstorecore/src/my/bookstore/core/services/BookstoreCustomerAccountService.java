package my.bookstore.core.services;

import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.core.model.user.CustomerModel;
import my.bookstore.core.enums.RewardStatusLevel;

import java.util.List;

public interface BookstoreCustomerAccountService {

    void updateRewardStatusPoints(CustomerModel customer, OrderModel order);
    List<CustomerModel> getAllCustomersForLevel(RewardStatusLevel level);


}
