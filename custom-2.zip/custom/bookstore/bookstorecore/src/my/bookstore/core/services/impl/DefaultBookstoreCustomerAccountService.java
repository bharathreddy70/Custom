package my.bookstore.core.services.impl;

import de.hybris.platform.commerceservices.customer.dao.impl.DefaultCustomerDao;
import de.hybris.platform.commerceservices.customer.impl.DefaultCustomerAccountService;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.core.model.user.CustomerModel;
import my.bookstore.core.services.BookstoreCustomerAccountService;
import my.bookstore.core.enums.RewardStatusLevel;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DefaultBookstoreCustomerAccountService extends DefaultCustomerAccountService implements BookstoreCustomerAccountService {

    private DefaultCustomerDao defaultCustomerDao;

    public DefaultBookstoreCustomerAccountService(DefaultCustomerDao defaultCustomerDao) {
        this.defaultCustomerDao = defaultCustomerDao;
    }

    @Override
    public void updateRewardStatusPoints(CustomerModel customer, OrderModel order) {
        int total = 0;
        List<AbstractOrderEntryModel> orderEntries = order.getEntries();
        for(AbstractOrderEntryModel orderEntry: orderEntries){
            ProductModel book = orderEntry.getProduct();
            total += orderEntry.getQuantity()*book.getRewardPoints();
        }
        customer.setPoints(customer.getPoints() + total);
        getModelService().save(customer);
    }
    @Override
    public List<CustomerModel> getAllCustomersForLevel(RewardStatusLevel level) {
        //select * from {Customer} where {rewardStatusLevel}=?level
        Map<String,RewardStatusLevel> params = new HashMap<>();
        params.put(CustomerModel.REWARDSTATUSLEVEL,level);
        return defaultCustomerDao.find(params);
    }
}
