/*
 * Copyright (c) 2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
package my.bookstore.core.jalo;

/**
 * Apparel variant of product.
 */
public class ApparelProduct extends GeneratedApparelProduct
{
	// Deliberately empty class
}
